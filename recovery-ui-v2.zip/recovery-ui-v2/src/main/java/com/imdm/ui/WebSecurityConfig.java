package com.imdm.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Value("${auth.username}")
    private String authUser;
    
	@Value("${auth.password}")
    private String authPass;
    
	@Value("${auth.ldap.url}")
    private String ldapUrl;
    
	@Value("${auth.ldap.port}")
    private String ldapPort;
    
	@Value("${auth.ldap.dc}")
    private String ldapDc;
	
	@Value("${auth.ldap.groupfilter}")
	private String groupFilter;
	
	

	/*@Autowired
	private EmployeeAuthenticationSuccessHandler successHandler;*/

	
	
	
	/*
	 * @Override public void configure(WebSecurity web) throws Exception {
	 * web.ignoring() .antMatchers("classpath:static/index.html"); }
	 */
	 
	 
	 

    /*@Override
    protected void configure(final HttpSecurity http) throws Exception {
        http
        .cors().and()
          .csrf().disable()
          .authorizeRequests()
          .antMatchers("/admin/**").hasRole("ADMIN")
          .antMatchers("/anonymous*").anonymous()
          .antMatchers("/login*").permitAll()
          .anyRequest().authenticated()
          .and()
          .formLogin()
          .loginPage("/login")
          //.loginProcessingUrl("/welcome")
          .defaultSuccessUrl("/welcome", true)
         .failureUrl("/login?error=true")
          //.failureHandler(authenticationFailureHandler())
          .and()
          .logout()
          //.logoutUrl("/perform_logout")
          .deleteCookies("JSESSIONID");
          //.logoutSuccessHandler(logoutSuccessHandler());
        
        //http.csrf().disable();
    }*/
	
	
	 @Override
		protected void configure(HttpSecurity http) throws Exception {
		 
		 http
		 .cors().and()
		 .csrf().disable().
			authorizeRequests()
			.antMatchers("/*").permitAll()
			.antMatchers(HttpMethod.OPTIONS, "/*").permitAll().anyRequest().authenticated()
			.and()
			.formLogin().loginPage("/login").failureUrl("/login?error")
			.and()
			.logout().logoutSuccessUrl("/login?logout")
			.and().httpBasic();
		 
			
		}
	 
	
   
    @Bean
    public WebMvcConfigurer corsConfigurer() {
	return new WebMvcConfigurer() {
		
		@Override
		public void addCorsMappings(CorsRegistry registry) {
			
			registry.addMapping("/**").allowedMethods("GET","POST","PUT","DELETE").allowedHeaders("*").allowedOrigins("*");
				}
			};
		}
    
   
	
   /* @Override 
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	
    	DefaultSpringSecurityContextSource context = new DefaultSpringSecurityContextSource(ldapUrl +":"+ ldapPort +"/"+ ldapDc);
         context.setUserDn("cn=" +authUser+ "," + ldapDc);
         context.setPassword(authPass);//authPass
         context.afterPropertiesSet();

         auth.ldapAuthentication()
         .contextSource(context)
         //.userSearchFilter("sAMAccountName={0}")
         //.userSearchFilter("(&(cn={0})(memberOf=cn=ind_mdm_data_steward,cn=Users,dc=ms,dc=ds,dc=uhc,dc=com))")
         .userSearchFilter(groupFilter)
         .userDetailsContextMapper(new UserDetailsService())
         .ldapAuthoritiesPopulator(new CustomLdapPopulator());

    }	*/
    
   
	
    
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder authenticationMgr) throws Exception {
		//authenticationMgr.inMemoryAuthentication().withUser("admin").password("admin").authorities("ROLE_USER").and()
			//	.withUser("imdmcicd").password("cal6Velo").authorities("ROLE_USER", "ROLE_ADMIN");
		
		authenticationMgr.inMemoryAuthentication().withUser("sunil").password(passwordEncoder().encode("12345")).roles("USER");
		//authenticationMgr.inMemoryAuthentication().withUser("admin").password("{noop}admin1234").roles("ADMIN");
		
		
	
	}
	
	@Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
	 
    
}
